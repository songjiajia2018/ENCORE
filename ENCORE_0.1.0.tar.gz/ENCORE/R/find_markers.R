#' Find group markers
#'
#' Using an expression matrix and cluster results as input, find_markers will output cell group markers.
#
#' @param data matrix; Data matrix (each row is an cell, each column is a gene).
#' @param temp data.frame; The temp element from result of encore_step2 including cluster result and two-dimensional distribution of cells.
#' @param top integer; default: 20; Maximum number of gene markers of each cluster in output.
#' @param thread integer; default: 1; Number of threads used
#' @param scale character; default: TRUE. Scale the data by log2 or log10.
#' @param clus vector; default: all; Clusters that need to screen markers. In default, this function will find markers for all clusters.
#' @param heatmap character; default: FALSE. Output the heatmap.
#' @param pc numeric; default: 0.0001; The cut-off of adjusted p value of group markers.
#'
#' @examples
#' result1=encore_step1(data,method="kmeans",start=50,thread=4)
#' result2=encore_step2(data=data,method="both",k=5,result=result1,thread=4)
#' markers=find_markers(data,temp=result2$temp,thread=10)
#'
#' @return A Dataframe
#' \item{gmarkers}{data.frame, containing group markers and their detailed information}
#'
#' @import parallel
#' @import pROC
#' @import qplots
#' @import gridExtra
#'
#' @export
find_markers=function(data,temp,top=20,thread=1,scale="TRUE",clus='all',pc=0.0001,heatmap="FALSE"){
  cluster=temp$clusters
  if(scale=="TRUE"||scale=="T"){
    max_data=max(data)
    if(max_data>10000){
      data=log(data+1)/log(10)
    }else{
      data=log(data+1)/log(2)
    }
  }
	my_test<-function(i){
        f=data[i,]
        tresult=cor.test(as.double(f),ncluster)
        p=tresult$p.value
        t=as.numeric(as.character(tresult$estimate))
        if(is.na(p)){
        }else if(p<pc && t>0){
        	t="up"
            comp=data.frame(as.double(f),ncluster)
            roc1=roc(comp[,2],comp[,1])
            auc1=as.numeric(roc1$auc)
            result=data.frame(p,auc1,name[i],t)
            row.names(result)=name[i]
            return(result)
        }else if(p<pc && t<0){
            t="down"
            comp=data.frame(as.double(f),ncluster)
            roc1=roc(comp[,2],comp[,1])
            auc1=as.numeric(roc1$auc)
            result=data.frame(p,auc1,name[i],t)
            row.names(result)=name[i]
            return(result)
        }else{
		}
	}
    clu=levels(as.factor(cluster))
    gmarkers=c()
    cluu=max(as.numeric(clu))
    data=as.data.frame(t(data))
	name=row.names(data)
	library(parallel)
  	cl <- makeCluster(getOption("cl.cores",thread),type="FORK")
	clusterExport(cl,"data",envir = environment())
	clusterExport(cl,"pc",envir = environment())
	clusterExport(cl,"name",envir = environment())
	if(clus=='all'){
		clus=1:cluu
	}
    for(i in clus){
    	ncluster=cluster
        ncluster=as.numeric(as.character(ncluster))
        nncluster=ncluster
        ncluster[nncluster!=as.numeric(i)]=0
        ncluster[nncluster==as.numeric(i)]=1
        rm(nncluster)
        clusterExport(cl,"ncluster",envir = environment())
        num=dim(data)[1]
        nums=1:num
        marker=parLapply(cl,nums,my_test)
        markers=do.call(rbind,marker)
        markers=as.data.frame(markers)
        markers$cluster=rep(i,dim(markers)[1])
        markers$p=p.adjust(markers$p,method="holm",n=num*length(clu))
        markers=markers[markers$p<pc,]
        z=order(markers$auc1,decreasing = TRUE)
        markers=markers[z,]
		if(dim(markers[1])>top){
        	gmarkers=rbind(gmarkers,markers[1:top,])
		}else{
			gmarkers=rbind(gmarkers,markers)
		}
        rm(ncluster)
		rm(markers)
    }
	stopCluster(cl)
	names(gmarkers)=c("p","iauc","gene","status","cluster")
	if(heatmap=="TRUE" || heatmap=="T"){
	  gmarkers1=gmarkers[gmarkers$status=="up",]
	  genes=gmarkers1$gene
	  genes=as.vector(genes)
	  data=as.data.frame(t(data))
	  agenes=names(data)
	  gexp=subset(data,select=genes)
	  cluster=as.data.frame(cluster)
	  row.names(cluster)=row.names(data)
	  names(cluster)=c("cluster")
	  total=merge(gexp,cluster,by="row.names")
	  nnn=total$Row.names
	  total=total[,-1]
	  total=total[order(total$cluster),]
	  da=total[,-dim(total)[2]]
	  b=total$cluster
	  b=as.character(b)
	  pdf(file="heatmap.pdf")
	  heatmap.2(as.matrix(t(da)),Colv=FALSE, Rowv=FALSE,scale="row", col=bluered,ColSideColors=b,key=TRUE,symkey=FALSE,density.info="none",trace="none",cexRow=0.25)
    dev.off()
	}
	clu=max(gmarkers$cluster)
	for(i in 1:clu){
	  marker=gmarkers[gmarkers$cluster==i,]
	  file_name=paste("feature_group",i,".pdf",sep='')
	  ps=list()
	  gene=marker$gene
	  for(j in gene){
	    tempp=data.frame(temp[,1:2],as.numeric(data[,j]))
	    names(tempp)=c("tsne_1","tsne_2","gene")
	    p=ggplot(data=tempp,aes(x=tsne_1,y=tsne_2,color=gene))+geom_point(size=0.5)+theme_bw()+theme(panel.border=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),axis.line=element_line(color='black'))+scale_color_gradient(low = 'gray', high = 'blue')
	    ps[[j]]=p

	  }
	  dim1=length(gene)
	  if(dim1==0){
	  }else if(dim1==1){
	    pdf(file=file_name,width=3, height=3)
	    grid.arrange(ps[[1]],nrow=1)
	    dev.off()
	  }else if(dim1==2){
	    pdf(file=file_name,width=6, height=3)
	    grid.arrange(ps[[1]],ps[[2]],nrow=1)
	    dev.off()
	  }else if(dim1==3){
	    pdf(file=file_name,width=9, height=3)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],nrow=1)
	    dev.off()
	  }else if(dim1==4){
	    pdf(file=file_name,width=12, height=3)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],nrow=1)
	    dev.off()
	  }else if(dim1==5){
	    pdf(file=file_name,width=12, height=6)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],nrow=2)
	    dev.off()
	  }else if(dim1==6){
	    pdf(file=file_name,width=12, height=6)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],nrow=2)
	    dev.off()
	  }else if(dim1==7){
	    pdf(file=file_name,width=12, height=6)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]], nrow=2)
	    dev.off()
	  }else if(dim1==8){
	    pdf(file=file_name,width=12, height=6)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],nrow=2)
	    dev.off()
	  }else if(dim1==9){
	    pdf(file=file_name,width=12, height=9)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],nrow=3)
	    dev.off()
	  }else if(dim1==10){
	    pdf(file=file_name,width=12, height=9)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],ps[[10]],nrow=3)
	    dev.off()
	  }else if(dim1==11){
	    pdf(file=file_name,width=12, height=9)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],ps[[10]],ps[[11]],nrow=3)
	    dev.off()
	  }else if(dim1==12){
	    pdf(file=file_name,width=12, height=9)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],ps[[10]],ps[[11]],ps[[12]],nrow=3)
	    dev.off()
	  }else if(dim1==13){
	    pdf(file=file_name,width=12, height=12)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],ps[[10]],ps[[11]],ps[[12]],ps[[13]],nrow=4)
	    dev.off()
	  }else if(dim1==14){
	    pdf(file=file_name,width=12, height=12)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],ps[[10]],ps[[11]],ps[[12]],ps[[13]],ps[[14]],nrow=4)
	    dev.off()
	  }else if(dim1==15){
	    pdf(file=file_name,width=12, height=12)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],ps[[10]],ps[[11]],ps[[12]],ps[[13]],ps[[14]],ps[[15]],nrow=4)
	    dev.off()
	  }else if(dim1==16){
	    pdf(file=file_name,width=12, height=12)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],ps[[10]],ps[[11]],ps[[12]],ps[[13]],ps[[14]],ps[[15]],ps[[16]],nrow=4)
	    dev.off()
	  }else if(dim1==17){
	    pdf(file=file_name,width=12, height=15)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],ps[[10]],ps[[11]],ps[[12]],ps[[13]],ps[[14]],ps[[15]],ps[[16]],ps[[17]],nrow=5)
	    dev.off()
	  }else if(dim1==18){
	    pdf(file=file_name,width=12, height=15)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],ps[[10]],ps[[11]],ps[[12]],ps[[13]],ps[[14]],ps[[15]],ps[[16]],ps[[17]],ps[[18]],nrow=5)
	    dev.off()
	  }else if(dim1==19){
	    pdf(file=file_name,width=12, height=15)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],ps[[10]],ps[[11]],ps[[12]],ps[[13]],ps[[14]],ps[[15]],ps[[16]],ps[[17]],ps[[18]],ps[[19]],nrow=5)
	    dev.off()
	  }else{
	    pdf(file=file_name,width=12, height=15)
	    grid.arrange(ps[[1]],ps[[2]],ps[[3]],ps[[4]],ps[[5]],ps[[6]],ps[[7]],ps[[8]],ps[[9]],ps[[10]],ps[[11]],ps[[12]],ps[[13]],ps[[14]],ps[[15]],ps[[16]],ps[[17]],ps[[18]],ps[[19]],ps[[20]],nrow=5)
	    dev.off()
	  }
	}
	return(gmarkers)
}

